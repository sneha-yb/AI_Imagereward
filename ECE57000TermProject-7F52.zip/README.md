Upload the given .ipynb file to google colab to execute it

demo video link- https://drive.google.com/file/d/1T3hUBB5HPks9EY9e23uXxRqBPv6Be-HD/view?usp=sharing
